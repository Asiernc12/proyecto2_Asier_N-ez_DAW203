'use strict'; // Activa el modo estricto para evitar errores comunes y garantizar un código más seguro.

document.addEventListener("DOMContentLoaded", inicio); // Ejecuta la función "inicio" cuando el contenido HTML esté completamente cargado.

function inicio() {
    const nombre = document.getElementById("nombre"); // Obtiene el campo de texto donde el jugador ingresa su nombre.
    const form = document.getElementById("inicio"); // Obtiene el formulario donde el jugador ingresa su nombre.
    const miP = document.getElementById("miP"); // Obtiene el párrafo para mostrar los mensajes de error.
    const btnJugar = document.getElementById("btnJugar"); // Obtiene el botón de "Jugar" que aparecerá después de validar el nombre.
    const btnNombre = document.getElementById("btnNombre"); // Obtiene el botón de "Introducir nombre" para empezar.
    const label = document.getElementsByTagName("label")[0]; // Obtiene la etiqueta "label" para personalizar el mensaje.
    const btnDado = document.getElementById("btnDado"); // Obtiene el botón de "Tirar dado" que será visible cuando inicie el juego.
    const contenedor = document.getElementById("contenedor"); // Obtiene el contenedor donde se visualizarán las opciones del juego.

    // Oculta los botones "Jugar" y "Tirar dado" al inicio para que solo aparezcan cuando se validen los datos.
    btnJugar.style.display = "none";
    contenedor.style.display = "none";

    // Añade un evento para validar el nombre al hacer clic en "Introducir nombre".
    btnNombre.addEventListener("click", (event) => {
        event.preventDefault(); // Evita que el formulario se envíe por defecto.
        if (validarNombre(nombre, miP)) { // Si el nombre es válido, realiza las siguientes acciones.
            btnNombre.style.display = "none"; // Oculta el botón "Introducir nombre".
            nombre.style.display = "none"; // Oculta el campo de entrada del nombre.
            label.textContent = `Mucha suerte en tu aventura, ${nombre.value}`; // Muestra un mensaje personalizado con el nombre.
            btnJugar.style.display = "block"; // Muestra el botón "Jugar".
        }
    });

    // Al hacer clic en "Jugar", oculta el formulario y crea la tabla del juego.
    btnJugar.addEventListener("click", () => {
        form.style.display = "none"; // Oculta el formulario.
        crearTabla(); // Llama a la función para crear la tabla.
        contenedor.style.display = "block"; // Muestra el contenedor donde se encuentra el tablero.
    });

    // Acción para tirar el dado
    btnDado.addEventListener("click", lanzarDado); // Al hacer clic en el botón "Tirar dado", llama a la función para tirar el dado.
}

// Función que valida que el nombre tenga al menos 4 caracteres y no contenga números
function validarNombre(nombre, miP) {
    const regex = /^[^\d]{4,}$/; // Expresión regular que asegura que el nombre tenga al menos 4 caracteres y no contenga números.
    if (!regex.test(nombre.value)) {
        mostrarError(miP, "Nombre incorrecto. Debe tener al menos 4 caracteres y no contener números."); // Si no cumple con la validación, muestra un error.
        return false; // Si la validación falla, no permite continuar.
    }
    limpiarError(miP); // Si el nombre es válido, limpia el mensaje de error.

    return true; // Devuelve true si el nombre es válido.
}

// Función para mostrar los mensajes de error.
function mostrarError(miP, mensaje) {
    miP.textContent = mensaje; // Establece el texto del mensaje en el párrafo.
    miP.style.color = "red"; // Cambia el color del texto a rojo para indicar error.
}

// Limpia el mensaje de error.
function limpiarError(miP) {
    miP.textContent = ""; // Borra cualquier texto de error previo.
}

// Función para crear la tabla del juego.
function crearTabla() {
    let table = `<table class="tabla-estilo">`; // Inicializa la tabla.

    // Bucle que genera 10 filas y 10 columnas
    for (let i = 1; i <= 10; i++) {
        table += `<tr>`; // Comienza una fila.
        for (let j = 1; j <= 10; j++) {
            // Si es la primera celda (1, 1), coloca la imagen del héroe.
            if (i === 1 && j === 1) {
                table += `<td id="start"><img src="./img/medival_knight_PNG15938.png" alt="Inicio"></td>`;
            }
            // Si es la última celda (10, 10), coloca la imagen del tesoro.
            else if (i === 10 && j === 10) {
                table += `<td id="end"><img src="./img/R (1).png" alt="Tesoro"></td>`;
            } else {
                table += `<td id=${i}-${j}></td>`; // Genera celdas vacías con identificadores únicos.
            }
        }
        table += `</tr>`; // Cierra cada fila.
    }

    table += `</table>`; // Cierra la tabla.
    const tabla = document.getElementById('tabla');
    tabla.innerHTML = table; // Inserta la tabla en el DOM.
}

let tiradas = 1;
// Función para tirar el dado y propagar la clase en las celdas.
function lanzarDado() {
    console.log(tiradas);
    tiradas++;
    const contenedorDado = document.getElementById("dado"); // Obtiene el contenedor donde se mostrará el dado.
    contenedorDado.style.display = "block"; // Muestra el contenedor del dado.
    const valorDado = Math.floor(Math.random() * 6) + 1; // Genera un número aleatorio entre 1 y 6.

    // Muestra el dado y el número que salió.
    contenedorDado.innerHTML = `
        <img src="./img/${valorDado}.png" alt="Dado ${valorDado}" class="imagen-dado">
        <p id="pDado">¡Has sacado un ${valorDado}!</p>
    `;
    propagarClase(valorDado); // Llama a la función para propagar la clase según el valor del dado.
}

// Propaga la clase "resaltada" en las celdas según el valor del dado.
function propagarClase(valorDado) {
    const tabla = document.querySelector("table"); // Selecciona la tabla del DOM.
    const celdas = tabla.querySelectorAll("td"); // Obtiene todas las celdas (<td>) de la tabla.
    let posicionHeroe; // Variable para almacenar la posición actual del héroe en la tabla.

    // Encuentra la celda que contiene la imagen del héroe.
    celdas.forEach((celda, index) => {
        // Busca una celda que contenga una imagen cuya fuente incluye "medival_knight_PNG15938.png".
        if (celda.querySelector("img") && celda.querySelector("img").src.includes("medival_knight_PNG15938.png")) {
            posicionHeroe = index; // Guarda el índice de la celda donde está el héroe.
        }
    })

    const filas = tabla.rows; // Obtiene todas las filas (<tr>) de la tabla.
    const numColumnas = filas[0].cells.length; // Determina el número de columnas de la tabla.
    const filaHeroe = Math.floor(posicionHeroe / numColumnas);
    // Calcula la fila actual del héroe dividiendo la posición por el número de columnas.
    const columnaHeroe = posicionHeroe % numColumnas;
    // Calcula la columna actual del héroe usando el resto de la división.

    // Elimina cualquier clase "resaltada" previa de todas las celdas.
    celdas.forEach((celda) => celda.classList.remove("resaltada"));

    // Resalta celdas en las direcciones cardinales (izquierda, derecha, arriba y abajo).
    for (let i = 1; i <= valorDado; i++) {
        // Resalta a la izquierda si está dentro de los límites.
        if (columnaHeroe - i >= 0) {
            filas[filaHeroe].cells[columnaHeroe - i].classList.add("resaltada");
        }
        // Resalta a la derecha si está dentro de los límites.
        if (columnaHeroe + i < numColumnas) {
            filas[filaHeroe].cells[columnaHeroe + i].classList.add("resaltada");
        }
        // Resalta hacia arriba si está dentro de los límites.
        if (filaHeroe - i >= 0) {
            filas[filaHeroe - i].cells[columnaHeroe].classList.add("resaltada");
        }
        // Resalta hacia abajo si está dentro de los límites.
        if (filaHeroe + i < filas.length) {
            filas[filaHeroe + i].cells[columnaHeroe].classList.add("resaltada");
        }
    }

    // Agrega un evento de clic a cada celda resaltada para permitir mover el héroe.
    celdas.forEach((celda) => {
        if (celda.classList.contains("resaltada")) {
            celda.addEventListener("click", moverHeroe); // Solo las celdas resaltadas pueden recibir clics.
        }
    });
}

// Función que maneja el movimiento del héroe dentro de la tabla al hacer clic en una celda resaltada
function moverHeroe(event) {
    const celdaSeleccionada = event.target.closest("td"); // Obtiene la celda en la que se hizo clic, subiendo hasta el elemento <td> más cercano.

    // Verifica si la celda seleccionada existe y tiene la clase "resaltada" (lo que indica que es una opción válida)
    if (celdaSeleccionada && celdaSeleccionada.classList.contains("resaltada")) {
        const tabla = document.querySelector("table"); // Obtiene la tabla en la que está el juego.
        const celdas = tabla.querySelectorAll("td"); // Obtiene todas las celdas <td> dentro de la tabla.

        // Limpia la celda actual donde está el héroe (eliminando la imagen del héroe).
        celdas.forEach((celda) => {
            if (celda.querySelector("img") && celda.querySelector("img").src.includes("medival_knight_PNG15938.png")) {
                celda.innerHTML = ""; // Elimina el contenido (imagen) de la celda donde estaba el héroe.
            }
        });

        // Coloca la imagen del héroe en la celda seleccionada por el usuario.
        celdaSeleccionada.innerHTML = '<img src="./img/medival_knight_PNG15938.png" alt="Héroe">';

        // Verifica si el héroe ha llegado a la celda del tesoro (celda con id "end").
        if (celdaSeleccionada.id === 'end') {
            alert("¡Felicidades! Has encontrado el tesoro."); // Muestra un mensaje de felicitación.
            document.getElementById("btnDado").disabled = true; // Desactiva el botón para tirar el dado, ya que el juego ha terminado.
            record(nombre.value, tiradas); // Llama a la función para guardar el récord si el héroe llega al tesoro.
        }

        // Elimina la clase "resaltada" de todas las celdas y remueve el evento de clic.
        celdas.forEach((celda) => {
            celda.classList.remove("resaltada"); // Elimina la clase "resaltada" de todas las celdas.
            celda.removeEventListener("click", moverHeroe); // Elimina el evento de clic para evitar que se mueva el héroe después de un movimiento.
        });
    }
}

// Función para verificar si el héroe ha llegado a la celda del tesoro
function verificarVictoria() {
    const tabla = document.querySelector("table"); // Obtiene la tabla que contiene el juego.
    const filas = Array.from(tabla.rows); // Convierte las filas de la tabla en un array para poder iterar sobre ellas.

    let filaHeroe, columnaHeroe, filaTesoro, columnaTesoro; // Variables para almacenar las coordenadas del héroe y el tesoro.

    // Itera sobre todas las filas y celdas para encontrar las posiciones del héroe y del tesoro.
    filas.forEach((fila, filaIndex) => {
        Array.from(fila.cells).forEach((celda, colIndex) => {
            // Busca la celda que contiene la imagen del héroe (medival_knight_PNG15938.png) y guarda su posición.
            if (celda.querySelector("img") && celda.querySelector("img").src.includes("medival_knight_PNG15938.png")) {
                filaHeroe = filaIndex; // Asigna la fila donde está el héroe.
                columnaHeroe = colIndex; // Asigna la columna donde está el héroe.
            }
            // Busca la celda que contiene la imagen del tesoro (R (1).png) y guarda su posición.
            if (celda.querySelector("img") && celda.querySelector("img").src.includes("R (1).png")) {
                filaTesoro = filaIndex; // Asigna la fila donde está el tesoro.
                columnaTesoro = colIndex; // Asigna la columna donde está el tesoro.
            }
        });
    });

    // Compara las coordenadas del héroe con las del tesoro. Si son iguales, significa que el héroe ha llegado al tesoro.
    if (filaHeroe === filaTesoro && columnaHeroe === columnaTesoro) {
        alert("¡Felicidades! Has encontrado el tesoro."); // Si el héroe ha llegado al tesoro, muestra un mensaje de victoria.
        document.getElementById("btnDado").disabled = true; // Desactiva el botón de "Tirar dado".
    }
}

// Función que guarda el récord si el jugador lo supera
function record(nombre, tiradas) {
    // Verificar si ya existe un récord guardado en el localStorage
    let recordGuardado = localStorage.getItem('record');

    // Si existe un récord guardado o si el jugador ha superado el récord
    if (!recordGuardado || tiradas < JSON.parse(recordGuardado).tiradas) {
        // Crear un objeto con el nuevo récord que incluye el nombre del jugador y la cantidad de tiradas
        let nuevoRecord = {
            nombre: nombre,
            tiradas: tiradas
        };

        // Guardar el nuevo récord en el localStorage, convirtiéndolo en una cadena JSON
        localStorage.setItem('record', JSON.stringify(nuevoRecord));

        // Imprimir en la consola el nuevo récord establecido
        console.log("Nuevo récord establecido:");
        console.log(nuevoRecord);
    } else {
        // Si el jugador no ha superado el récord, mostrar mensaje en la consola
        console.log("No has superado el récord.");
    }
}

